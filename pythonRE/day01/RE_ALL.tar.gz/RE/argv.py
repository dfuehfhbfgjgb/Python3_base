import sys

#　获取命令行参数
print(sys.argv)